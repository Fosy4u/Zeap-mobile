import { initializeApp } from "@react-native-firebase/app";

const storageBucket = process.env.ENV === "dev"
    ? process.env.REACT_APP_FIREBASE_STORAGE_BUCKET_DEV
    : process.env.REACT_APP_FIREBASE_STORAGE_BUCKET_PROD;

const firebaseConfig = {
    apiKey: process.env.REACT_APP_FIREBASE_API_KEY || "",
    authDomain: process.env.REACT_APP_FIREBASE_AUTH_DOMAIN || "",
    projectId: process.env.REACT_APP_FIREBASE_PROJECT_ID || "",
    storageBucket: storageBucket,
    messagingSenderId: process.env.REACT_APP_FIREBASE_MESSAGING_SENDER_ID || "",
    appId: process.env.REACT_APP_FIREBASE_APP_ID || "",
};

const firebaseApp = initializeApp(firebaseConfig);
export default firebaseApp;