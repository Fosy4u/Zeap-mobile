import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import IProductState, { ICategory, INewestProduct } from "../models/productState_model";
import IProduct from "../models/product_model";
import { IColorEnum } from "../../../general/models/productOptions_model";
import IProductDetails from "../models/productDetails_model";
import { set } from "react-hook-form";

const initialState: IProductState = {
    productID: "",
    tabs: ["Description", "Reviews", "Timeline"],
    selectedTab: "Description",
    timelines: ["Once measurement received", "Cutting - 2days", "Sewing - 2 weeks", "Finishing 3 days", "Dispatch 2 days", "Delivery"],
    savedAddresses: [
        {
            id: "01",
            title: "Otor John Stephen",
            phone: "08130000000",
            email: "otorjohn@gmail.com",
            streetAddress: "No.38 Ashiek Jarma street, Jabi Abuja"
        },
        {
            id: "02",
            title: "Otor John Stephen",
            phone: "08130000000",
            email: "otorjohn@gmail.com",
            streetAddress: "No.38 Ashiek Jarma street, Jabi Abuja"
        },
    ],

    
    product: {},
    products: [],
    selectedCategory:{
        id: 1,
        name: "Female Clothings",
        totalCount: 0,
        color: ["#FFF4DF", "#FFE9BC"],
        image: require("../../../../../assets/images/home/category_one.png"),
    },
    categories: [
        {
            id: 1,
            name: "Female Clothings",
            totalCount: 0,
            color: ["#FFF4DF", "#FFE9BC"],
            image: require("../../../../../assets/images/home/category_one.png"),
        },
        {
            id: 2,
            name: "Male Clothings",
            totalCount: 0,
            color: ["#FEF4E6", "#FDD8A5"],
            image: require("../../../../../assets/images/home/category_four.png"),
        },
        {
            id: 3,
            name: "Shoes",
            totalCount: 0,
            color: ["#EAE2FF", "#CCBAFF"],
            image: require("../../../../../assets/images/home/category_two.png"),
        },
        {
            id: 4,
            name: "Accessories",
            totalCount: 0,
            color: ["#FFEFE5", "#FFDCC7"],
            image: require("../../../../../assets/images/home/category_three.png"),
        },
        {
            id: 5,
            name: "Bags",
            totalCount: 0,
            color: ["#FFECEA", "#FEBCB4"],
            image: require("../../../../../assets/images/home/category_five.png"),
        },
    ],
    newestProducts: [],
    femaleClothing: [],
    maleClothing: [],
    shoes: [],
    accessories: [],
    bags: [],
    popularProducts: [],

    featuredPrice: 0,
    selectedColor: {
        background: "",
        name: "",
        hex: ""
    },
    selectedSize: "",
    selectedQuantity: 1,

    searchPhrases: ["Women jacket", "Men jacket", "Men’s summer sweater", "Joggers", "Kids hoodie"],
    filteredSearchPhrases: ["Women jacket", "Men jacket", "Men’s summer sweater", "Joggers", "Kids hoodie"],
    searchWord: "",
    showSizedGuideBottomSheet: false,
};

export const productSlice = createSlice({
    name: "productSlice",
    initialState,
    reducers: {
        setSearchWord: (state: IProductState, action: PayloadAction<string>) => {
            state.searchWord = action.payload;
            if (action.payload === "") {
                state.filteredSearchPhrases = state.searchPhrases;
                return;
            }
            state.filteredSearchPhrases = state.searchPhrases.filter(phrase => phrase.toLowerCase().includes(action.payload.toLowerCase()));
        },
        setProductID: (state: IProductState, action: PayloadAction<string>) => {
            state.productID = action.payload;
        },
        setProduct: (state: IProductState, action: PayloadAction<IProductDetails>) => {
            state.product = action.payload;
        },
        setProducts: (state: IProductState, action: PayloadAction<IProduct[]>) => {
            state.products = action.payload;
        },
        setSelectedTab: (state: IProductState, action: PayloadAction<string>) => {
            state.selectedTab = action.payload;
        },
        setNewestProducts: (state: IProductState, action: PayloadAction<INewestProduct[]>) => {
            state.newestProducts = action.payload;
        },
        setFemaleClothing: (state: IProductState, action: PayloadAction<IProduct[]>) => {
            state.femaleClothing = action.payload;
        },
        setMaleClothing: (state: IProductState, action: PayloadAction<IProduct[]>) => {
            state.maleClothing = action.payload;
        },
        setShoes: (state: IProductState, action: PayloadAction<IProduct[]>) => {
            state.shoes = action.payload;
        },
        setAccessories: (state: IProductState, action: PayloadAction<IProduct[]>) => {
            state.accessories = action.payload;
        },
        setBags: (state: IProductState, action: PayloadAction<IProduct[]>) => {
            state.bags = action.payload;
        },
        setCategories: (state: IProductState, action: PayloadAction<{ name: string, totalCount: number} >) => {
            const { name, totalCount } = action.payload;

            // Update only the matching category
            state.categories = state.categories.map(category => 
                category.name === name
                ? { ...category, totalCount }
                : category
            );
        },
        setSelectedCategory: (state: IProductState, action: PayloadAction<ICategory>) => {
            state.selectedCategory = action.payload;
        },
        setPopularProducts: (state: IProductState, action: PayloadAction<IProduct[]>) => {
            state.popularProducts = action.payload;
        },
        setFeaturedPrice: (state: IProductState, action: PayloadAction<number>) => {
            state.featuredPrice = action.payload;
        },
        setSelectedColor: (state: IProductState, action: PayloadAction<IColorEnum>) => {
            state.selectedColor = action.payload;
        },
        setSelectedSize: (state: IProductState, action: PayloadAction<string>) => {
            state.selectedSize = action.payload;
        },
        setSelectedQuantity: (state: IProductState, action: PayloadAction<number>) => {
            state.selectedQuantity = action.payload;
        },
        setShowSizedGuideBottomSheet: (state: IProductState, action: PayloadAction<boolean>) => {
            state.showSizedGuideBottomSheet = action.payload;
        }
    }
});

const { actions, reducer } = productSlice;

export const {
    setSearchWord,
    setProduct,
    setProducts,
    setProductID,
    setSelectedTab,
    setNewestProducts,
    setFemaleClothing,
    setMaleClothing,
    setShoes,
    setAccessories,
    setBags,
    setCategories,
    setSelectedCategory,
    setPopularProducts,
    setFeaturedPrice,
    setSelectedColor,
    setSelectedSize,
    setSelectedQuantity,
    setShowSizedGuideBottomSheet,
} = actions;
export default reducer;